import pandas as pd
import csv
import matplotlib.pyplot as plt
import numpy as np

#df = pd.read_csv('graph5.csv', encoding='utf8')
#df = pd.read_csv('graph6.csv', encoding='utf8')
df = pd.read_csv('graph4.csv', encoding='utf8')
#df = pd.read_csv('graph3.csv', encoding='utf8')
#df = pd.read_csv('graph2.csv', encoding='utf8')
#df = pd.read_csv('graph1.csv', encoding='utf8')
#df['Num. of occurrences'] = (df['Num. of occurrences'] - df['Num. of occurrences'].mean()) + df['Num. of occurrences'].mean()
ax = plt.figure().add_subplot(111)
#df.plot(ax=ax, x="ML tools", y=["dos", "buf.-overflow", "arbi.-code-ex.", "xss", "open-redir.", "symlink-attack"], color=['whitesmoke','gainsboro','silver','lightgray','gray', 'dimgray'], kind="bar", width=0.9, figsize=(16.5,2.0))
#df.plot(ax=ax, x="ML tools", y=["arbi.-code-ex.", "rce", "buf.-overflow", "dos", "out-of-bounds", "uaf", "div.-by-zero", "null ptr deref.", "code-injection"], color=['whitesmoke','gainsboro','silver','lightgray','gray', 'dimgray'], width=0.9, kind="bar", figsize=(16.5,2.0))
ax = df.plot.bar(x='ML tools',y='Total vulnerabilities',color='whitesmoke',rot=0,figsize=(6.4,2)) 
#ax = df.plot.bar(x='Vulnerability type',y='Num. of occurrences',color='silver',rot=0, figsize=(6.4,2)) 
#ax.set(xlabel="ML tools")
#plt.legend(fontsize=8)
plt.xlabel('ML tools', fontsize=7)
plt.ylabel('Total vulnerabilities', fontsize=7)
#plt.xlabel('Vulnerability type', fontsize=7)
#plt.ylabel('Num. of occurrences', fontsize=7)
plt.xticks(fontsize=6.5,rotation=39)
#plt.yticks(np.arange(0, 7.5, 2.0))
plt.yticks(fontsize=7.5)

bars = ax.patches
patterns =('..', '\\\\', '////', '--', '..', 'oo')
#patterns =('--', '**','*', '//','\\','o','.')
hatches = [p for p in patterns for i in range(len(df))]
for bar, hatch in zip(bars, hatches):
    bar.set_hatch(hatch)
#ax.legend(loc='upper right',ncol=len(df.columns))
#ax.legend()
#plt.show()
#plt.savefig('advisorydb_attack_distribution_per_tool.pdf',bbox_inches='tight')
#plt.savefig('github_issues_attack_distribution_per_tool.pdf',bbox_inches='tight')
plt.legend().remove()
plt.savefig('advisorydb_potential_attack_per_tool.pdf',bbox_inches='tight')
#plt.savefig('potential_attack_per_tool.pdf',bbox_inches='tight')
#plt.savefig('github_advisorydb_attack_total.pdf',bbox_inches='tight')
#plt.savefig('github_issues_attack_total.pdf',bbox_inches='tight')