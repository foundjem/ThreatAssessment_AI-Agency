https://atlas.mitre.org/studies
